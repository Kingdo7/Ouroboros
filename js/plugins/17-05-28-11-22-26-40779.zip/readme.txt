Terraxlighting.zip only contains the script.

Demo.zip contains a simple demo, just create a new project and overwrite the data and js directorys with the files in demo.zip

This zip contains java-script files, some virus and malware detectors might flag it as a possible danger.
If you don't trust it, you can also download it in plain text from

https://github.com/Terraxz/TerraxLighting 

Terrax.
